1. Item Ratings (ratings.txt): [user-id, item-id, rating-value]

2. Trust Ratings (trust.txt):  [user-id (trustor), user-id (trustee), trust-value]

The trust links are directed. 

3. To use this data set in your research, please consider to cite our work: 

   Guibing Guo, Jie Zhang and Neil Yorke-Smith. A Novel Bayesian Similarity Measure for Recommender Systems. Proceedings of the 23rd International Joint Conference on Artifical Intelligence. IJCAI 2013.


Copy Right 2013
Guibing Guo
guoguibing@gmail.com